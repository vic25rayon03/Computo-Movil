//
//  ViewController.swift
//  Ex2
//
//  Created by Usuario invitado on 29/10/18.
//  Copyright © 2018 UNAM. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func boton1(_ sender: UISwitch) {
        
        if sender.isOn{
            
           print("respuesta correcta")
            
        }
        else{
            print("Respuesta incorrecta")
        }
      
    }
    
}

